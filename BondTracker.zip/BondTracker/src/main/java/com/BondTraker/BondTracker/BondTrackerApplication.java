package com.BondTraker.BondTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BondTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BondTrackerApplication.class, args);
	}

}
