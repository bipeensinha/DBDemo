package com.BondTraker.BondTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BondTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
