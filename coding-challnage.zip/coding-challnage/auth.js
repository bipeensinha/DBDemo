function register(event) {
  event.preventDefault();
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value.toLowerCase();
  const password = document.getElementById("password").value;

  if (localStorage.getItem(email)) {
    alert("User already exists. Please login.");
    window.location.href = "login.html";
    return;
  }

  const user = { name, email, password };
  localStorage.setItem(email, JSON.stringify(user));
  alert("Registration successful! Please login.");
  window.location.href = "login.html";
}

function login(event) {
  event.preventDefault();
  const email = document.getElementById("email").value.toLowerCase();
  const password = document.getElementById("password").value;

  const storedUser = JSON.parse(localStorage.getItem(email));
  if (!storedUser || storedUser.password !== password) {
    alert("Invalid email or password.");
    return;
  }

  localStorage.setItem("loggedInUser", JSON.stringify(storedUser));
  window.location.href = "index.html";
}
