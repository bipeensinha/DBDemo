// Sample bond data
const bonds = [
  { isin: "DE000001", issuer: "BMW", counterparty: "Client A", maturity: "2025-08-03", status: "OPEN" },
  { isin: "DE000002", issuer: "Siemens", counterparty: "Client B", maturity: "2025-07-28", status: "OPEN" },
  { isin: "DE000003", issuer: "Volkswagen", counterparty: "Client C", maturity: "2025-08-01", status: "REDEEMED" },
  { isin: "DE000004", issuer: "BASF", counterparty: "Client D", maturity: "2025-08-10", status: "OPEN" },
  { isin: "DE000005", issuer: "SAP", counterparty: "Client E", maturity: "2025-07-27", status: "OPEN" }
];

// Utility function to get difference in days
function daysBetween(date1, date2) {
  return Math.floor((date1 - date2) / (1000 * 60 * 60 * 24));
}

// Filter and display bonds
function filterBonds() {
  const filter = document.getElementById("filter").value;
  const today = new Date();
  const tbody = document.getElementById("bondTableBody");
  tbody.innerHTML = "";

  bonds.forEach(bond => {
    const maturityDate = new Date(bond.maturity);
    const diff = daysBetween(maturityDate, today);
    let show = false;

    if (filter === "all") show = true;
    else if (filter === "upcoming" && diff >= 0 && diff <= 5) show = true;
    else if (filter === "recent" && diff < 0 && diff >= -5) show = true;

    if (show) {
      const row = `<tr>
        <td>${bond.isin}</td>
        <td>${bond.issuer}</td>
        <td>${bond.counterparty}</td>
        <td>${bond.maturity}</td>
        <td>${bond.status}</td>
      </tr>`;
      tbody.innerHTML += row;
    }
  });
}

// Logout
function logout() {
  localStorage.removeItem("loggedInUser");
  window.location.href = "login.html";
}

// Show user name in header (top-right corner)
function showLoggedInUser() {
  const user = JSON.parse(localStorage.getItem("loggedInUser"));
  if (user && user.email) {
    const username = user.name || user.email.split("@")[0];
    const header = document.querySelector("header");
    const userSpan = document.createElement("span");
    userSpan.textContent = `👤 Welcome, ${username}`;
    userSpan.style.marginLeft = "auto";
    userSpan.style.marginRight = "20px";
    userSpan.style.fontWeight = "bold";
    userSpan.style.color = "#003366";
    header.appendChild(userSpan);
  }
}

// Load bonds on page load
window.onload = function () {
  showLoggedInUser();
  filterBonds();
};
