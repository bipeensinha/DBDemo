package com.example.cachingdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CachingdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
