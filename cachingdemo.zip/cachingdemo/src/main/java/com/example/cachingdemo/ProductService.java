package com.example.cachingdemo.service;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    @Cacheable("products")
    public String getProductById(String id) {
        simulateSlowService();
        return "Product-" + id;
    }

    private void simulateSlowService() {
        try {
            Thread.sleep(3000); // simulate slow call
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
    }
}
