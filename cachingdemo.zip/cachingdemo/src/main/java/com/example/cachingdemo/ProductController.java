package com.example.cachingdemo.controller;

import com.example.cachingdemo.service.ProductService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @GetMapping("/product/{id}")
    public String getProduct(@PathVariable String id) {
        return service.getProductById(id);
    }
}
