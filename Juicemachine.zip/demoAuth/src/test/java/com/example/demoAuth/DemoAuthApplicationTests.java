package com.example.demoAuth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
