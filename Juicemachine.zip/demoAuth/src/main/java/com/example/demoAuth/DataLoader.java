package com.example.demoAuth;

import com.example.demoAuth.model.User;
import com.example.demoAuth.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner init(UserRepository userRepository, BCryptPasswordEncoder passwordEncoder) {
        return args -> {
            if (userRepository.findByUsername("user1") == null) {
                User user = new User();
                user.setUsername("user1");
                user.setPassword(passwordEncoder.encode("password"));
                userRepository.save(user);
                System.out.println("User 'user1' with password 'password' created.");
            }
        };
    }
}