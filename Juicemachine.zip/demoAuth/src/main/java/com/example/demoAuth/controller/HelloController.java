package com.example.demoAuth.controller;

import org.springframework.web.bind.annotation.*;

@RestController
public class HelloController {

    @GetMapping("/public")
    public String publicEndpoint() {
        return "This is a public page and no Security Required.";
    }

    @GetMapping("/secure")
    public String secureEndpoint() {
        return "This Website is secure and created by Bipeen";
    }
}