package com.bank.demo_H2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import javax.sql.DataSource;

@SpringBootApplication
public class DemoH2Application {

	public static void main(String[] args) {

		ConfigurableApplicationContext context= SpringApplication.run(DemoH2Application.class, args);
		Object dataSource = context.getBean(DataSource.class);
		System.out.println(dataSource);
	}

}
