package com.bank.demo_H2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
