package com.bank.Juicemachine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuicemachineApplication {

	public static void main(String[] args) {

		SpringApplication.run(JuicemachineApplication.class, args);
	}

}
