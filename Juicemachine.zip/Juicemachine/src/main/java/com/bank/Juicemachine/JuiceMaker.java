package com.bank.Juicemachine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JuiceMaker {
    private final Fruit fruit;

    @Autowired
    public JuiceMaker(Fruit fruit)
    {
        this.fruit = fruit;
    }

    public String makeJuice ()
    {
        return "Juice made from " + fruit.getName();
    }
}
