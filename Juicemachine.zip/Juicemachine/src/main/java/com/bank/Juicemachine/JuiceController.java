package com.bank.Juicemachine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JuiceController {
    private final JuiceMaker juiceMaker;

    @Autowired
    public JuiceController (JuiceMaker juiceMaker)
    {
        this.juiceMaker = juiceMaker;

    }

    @GetMapping("/juice")
    public String getJuice()
    {
        return  juiceMaker.makeJuice();
    }
}
